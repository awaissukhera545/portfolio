import Blogs from "@/components/blog/Blogs";
import Copyright from "@/components/footers/Copyright";
import FooterAlt from "@/components/footers/FooterAlt";
import Header from "@/components/headers/Header";
import { allBlogs } from "@/data/blogs";
import { slugify } from "@/utlis/slugify";
import Link from "next/link";
import React from "react";
import CommonComponents from "@/components/common/CommonComponents";
export const metadata = {
  title:
    "Blog || Personal Portfolio React Nextjs Template | Freelancer & Developer Portfolio",
  description:
    "Personal Portfolio React Nextjs Template | Freelancer & Developer Portfolio",
};
export default async function TagPage({ params }) {
  let tagTitle = "";
  const { tag } = await params;
  const blogs = allBlogs.filter((blog) =>
    blog.tags?.some((el) => slugify(el) == tag)
  );
  allBlogs[0].tags.forEach((element) => {
    if (slugify(element) == tag) {
      tagTitle = element;
    }
  });
  return (
    <>
      <Header />
      <div className="breadcrumb-area breadcrumb-bg">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="breadcrumb-inner text-center">
                <h1 className="title split-collab">
                  {tagTitle ? tagTitle : <> {tag}</>}
                </h1>
                <ul className="page-list">
                  <li className="tmp-breadcrumb-item">
                    <Link href={`/`}>Home</Link>
                  </li>
                  <li className="icon">
                    <i className="fa-solid fa-angle-right" />
                  </li>
                  <li className="tmp-breadcrumb-item">Blog</li>
                  <li className="icon">
                    <i className="fa-solid fa-angle-right" />
                  </li>
                  <li className="tmp-breadcrumb-item active">Tag</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Blogs allBlogs={blogs} />
      <FooterAlt />
      <Copyright /> <CommonComponents />
    </>
  );
}
