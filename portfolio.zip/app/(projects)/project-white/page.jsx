import Copyright from "@/components/footers/Copyright";
import Footer from "@/components/footers/Footer";
import Header from "@/components/headers/Header";
import Projects from "@/components/projects/Projects";
import Link from "next/link";
import React from "react";
import CommonComponents from "@/components/common/CommonComponents";
export const metadata = {
  title:
    "Project || Personal Portfolio React Nextjs Template | Freelancer & Developer Portfolio",
  description:
    "Personal Portfolio React Nextjs Template | Freelancer & Developer Portfolio",
};
export default function page() {
  return (
    <>
      <div className="tmp-white-version">
        <div className="project inner">
          <Header />
          <div className="breadcrumb-area breadcrumb-bg">
            <div className="container">
              <div className="row">
                <div className="col-lg-12">
                  <div className="breadcrumb-inner text-center">
                    <h1 className="title split-collab">Project</h1>
                    <ul className="page-list">
                      <li className="tmp-breadcrumb-item">
                        <Link href={`/`}>Home</Link>
                      </li>
                      <li className="icon">
                        <i className="fa-solid fa-angle-right" />
                      </li>
                      <li className="tmp-breadcrumb-item active">Project</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Projects isLight />
          <Footer />
          <Copyright /> <CommonComponents />
        </div>
      </div>
    </>
  );
}
